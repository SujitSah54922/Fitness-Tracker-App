using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace dotnetapp.Exceptions
{

    public class WorkoutException : Exception
    {
        public WorkoutException() { }

        public WorkoutException(string message) : base() { }

        public WorkoutException(string message, Exception inner):base(message, inner) { }
    }
}
