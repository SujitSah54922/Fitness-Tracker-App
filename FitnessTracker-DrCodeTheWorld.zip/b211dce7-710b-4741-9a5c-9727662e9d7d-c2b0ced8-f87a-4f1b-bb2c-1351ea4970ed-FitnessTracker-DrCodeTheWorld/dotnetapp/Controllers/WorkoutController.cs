using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using dotnetapp.Exceptions;
using dotnetapp.Models;
using dotnetapp.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;

namespace dotnetapp.Controllers
{
    [ApiController]
    [Route("api/workout")]
    [EnableCors("corsapp")]
    [Authorize]
    public class WorkoutController : ControllerBase
    {
        private readonly WorkoutService _workoutService;
        public WorkoutController(WorkoutService workoutService)
        {
            _workoutService = workoutService;
        }
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Workout>>> GetAllWorkouts()
        {
            Console.WriteLine("InWorkout");
            try
            {
                var workOutList = await _workoutService.GetAllWorkouts();
                if(workOutList != null)
                {
                    return Ok(workOutList);
                }
                else
                {
                    throw new Exception(); 
                }
            }
            catch (Exception e)
            {
                
                return StatusCode(500, e.Message);
            }
        }
        [HttpGet("{workoutId}")]
        public async Task<ActionResult<Workout>> GetWorkoutById(int workoutId)
        {
            Console.WriteLine("In GetWorkoutById");
            try
            {
                var workout = await _workoutService.GetWorkoutById(workoutId);
                if(workout != null)
                {
                    return Ok(workout);
                }
                else
                {
                    return StatusCode(404, "No workout was found.");
                }

            }
            catch (Exception e)
            {
                return StatusCode(404, e.Message);
            }
            
        }
        [HttpPost]
        public async Task<ActionResult> AddWorkout([FromBody] Workout workout)
        {
            Console.WriteLine("In Add Workout");
            try
            {         
                if(await _workoutService.AddWorkout(workout))
                {
                    //var message ="Workout added successfully";
                    //return StatusCode(200, "Workout added successfully");
                    return Ok();
                    //new{msg=message}
                }
                else
                {
                    return StatusCode(500, "Failed to add workout");
                }
            }
            // catch(WorkoutException f)
            // {
            //     return (f.Message);
            // }
            catch (Exception e)
            {
                return StatusCode(500, e.Message);
            }
        }


        [HttpPut]
        public async Task<ActionResult> UpdateWorkout(int workoutId, [FromBody] Workout workout)
        {
            try
            {
                if( await _workoutService.UpdateWorkout(workoutId, workout))
                {
                    return Ok();
                }
                else
                {
                    return StatusCode(404, "No Workout was found");
                }
            }
            catch (Exception e)
            {
               return StatusCode(500, e.Message);
            }
        }
        [HttpDelete("{workoutId}")]
        public async Task<ActionResult> DeleteWorkout(int workoutId)
        {
            try
            {
                if(await _workoutService.DeleteWorkout(workoutId))
                {
                    return Ok();
                }
                else
                    return StatusCode(404, "Cannot find any workout");
            }
            catch (Exception e)
            {
               return StatusCode(500, e.Message);
            }
        }
    }
}