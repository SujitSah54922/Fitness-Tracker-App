using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using dotnetapp.Services;
using dotnetapp.Exceptions;
using dotnetapp.Models;
using Microsoft.AspNetCore.Cors;
using dotnetapp.Data;

namespace dotnetapp.Controllers
{
    [ApiController]
    [Route("api/workoutrequests")]
    [EnableCors("corsapp")]
    public class WorkoutRequestController : ControllerBase
    {
        //private readonly ApplicationDbContext _context;
        private readonly WorkoutRequestService _workoutRequestService;
        public WorkoutRequestController(WorkoutRequestService workoutRequestService)
        {
            _workoutRequestService = workoutRequestService;
        }
        [HttpGet]
        public async Task<ActionResult<IEnumerable<WorkoutRequest>>> GetAllWorkoutRequest()
        {
            try
            {
                var listOfWorkoutRequest =  await _workoutRequestService.GetAllWorkoutRequests();
                if (listOfWorkoutRequest != null)
                {
                    return Ok(listOfWorkoutRequest);

                }
                else
                {
                    throw new WorkoutException("No Workout Request Found");
                }
            }
            catch (WorkoutException e)
            {
                return StatusCode(500, e.Message);
            }
        }
        [HttpGet("{userId}")]
        public async Task<ActionResult<IEnumerable<WorkoutRequest>>> GetWorkoutRequestsByUserId(string userId)
        {
            try
            {
                var response = await _workoutRequestService.GetWorkoutRequestsByUserId(userId);
                if (response != null)
                {
                    return Ok(response);
                }
                else
                {
                    //throw new WorkoutException("No Workout Request Found for this user");
                    return StatusCode(404, "No Workout Request Found for this user");
                }
            }
            catch (Exception e)
            {
                return StatusCode(500, e.Message);
            }
        }
        [HttpPost]
        public async Task<ActionResult> AddWorkoutRequest([FromBody] WorkoutRequest workoutRequest)
        {
            try
            {
                bool result = await _workoutRequestService.AddWorkoutRequest(workoutRequest);
                if(result)
                {
                    return Ok();
                }
                else
                {
                    return StatusCode(500, "Failed to add workout request");
                }
            }
            catch (Exception e)
            {

                return StatusCode(500, e.Message);
            }
        }
        [HttpPut("{workoutRequestId}")]
        public async Task<ActionResult> UpdateWorkoutRequest(int workoutRequestId, [FromBody] WorkoutRequest workoutRequest)
        {
            try
            {
                if (await _workoutRequestService.UpdateWorkoutRequest(workoutRequestId, workoutRequest))
                {
                    return Ok();
                    //200, "Workout Request updated successfully"
                }
                else
                {
                    return StatusCode(404, "No Workout Request was found");
                }
            }
            catch (Exception e)
            {
                return StatusCode(500, e.Message);
            }
        }
        [HttpDelete("{workoutRequestId}")]
        public async Task<ActionResult> DeleteWorkoutRequest(int workoutRequestId)
        {
            try
            {
                if (await _workoutRequestService.DeleteWorkoutRequest(workoutRequestId))
                {
                    return Ok();
                }
                else
                    return StatusCode(404, "Cannot find any workout request");
            }
            catch (Exception e)
            {
                return StatusCode(500, e.Message);
            }
        }
    }
}
