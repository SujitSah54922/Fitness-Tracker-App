using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using dotnetapp.Services;
using Microsoft.AspNetCore.Mvc;
using dotnetapp.Models;
using Microsoft.AspNetCore.Cors;

namespace dotnetapp.Controllers
{
    [ApiController]
    [Route("api/feedback")]
    [EnableCors("corsapp")]
    public class FeedbackController : ControllerBase
    {
        private readonly FeedbackService _feedbackService;

        public FeedbackController(FeedbackService feedbackService)
        {
            _feedbackService = feedbackService;
        }
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Feedback>>> GetAllFeedbacks()
        {
            Console.WriteLine("In GetAllFeedbacks Controller");
            try
            {
                var listOfFeedback = await _feedbackService.GetAllFeedbacks();
                if (listOfFeedback != null)
                {
                    return Ok(listOfFeedback);
                }
                else
                {
                    return StatusCode(404, "No feedbacks were found.");
 
                }
            }
            catch (Exception e)
            {
                return StatusCode(500, e.Message);

            }
        }
        [HttpGet("user/{userId}")]
        public async Task<ActionResult<IEnumerable<Feedback>>> GetFeedbacksByUserId(string userId)
        {
            try
            {
                var getUser = await _feedbackService.GetFeedbacksByUserId(userId);
                if (getUser != null)
                {
                    return Ok(getUser);
                }
                else
                {
                    return StatusCode(404, "No Feedback were found for this user");
                }
            }
            catch (Exception e)
            {
                return StatusCode(500, e.Message);

            }
        }
        [HttpPost]
        public async Task<ActionResult> AddFeedback([FromBody] Feedback feedback)
        {
            try
            {
                var feedbackAddedOrNot =await _feedbackService.AddFeedback(feedback);
                if(feedbackAddedOrNot)
                {
                    //200, "Feedback added successfully"
                    return Ok();
                }
                else
                {
                    throw new Exception();
                }
            }
            catch (Exception e)
            {
                return StatusCode(500, e.Message);
            }
            
        }
        [HttpDelete("{feedbackId}")]
        public async Task<ActionResult> DeleteFeedback(int feedbackId)
        {
            var deletedOrNot = await _feedbackService.DeleteFeedback(feedbackId);
            try
            {
                if(deletedOrNot)
                {
                    return Ok();
                }
                else
                {
                    return StatusCode(404,"Cannot find any feedback");
                }
            }
            catch (Exception e)
            {
                return StatusCode(500, e.Message);
            }
        }
    }
}