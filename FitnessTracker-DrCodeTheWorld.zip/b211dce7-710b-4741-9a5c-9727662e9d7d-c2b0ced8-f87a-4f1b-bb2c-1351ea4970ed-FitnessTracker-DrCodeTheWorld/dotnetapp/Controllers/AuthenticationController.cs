using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using dotnetapp.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Cors;
using dotnetapp.Models;
//using Internal;
//using Internal;
//using Internal;
//using Internal;

namespace dotnetapp.Controllers
{
    [ApiController]
    [Route("api/")]
    [EnableCors("corsapp")]
    public class AuthenticationController : ControllerBase
    {
        private readonly AuthService _authService;

        public AuthenticationController(AuthService authService)
        {
            _authService = authService;
        }
        [HttpPost("login")]
        public async Task<IActionResult> Login(LoginModel model)
        {
            // Console.WriteLine("Login Enter1");
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest();
                }
                var (statusCode,TokenOrMessage) = await _authService.Login(model);

                Console.WriteLine(statusCode);
                Console.WriteLine(TokenOrMessage);
                if (statusCode==1)
                {
                    //return StatusCode(200, message);
                    return Ok(new{Token = TokenOrMessage});
                }
                else
                {
                    return Unauthorized(new{Message = TokenOrMessage});
                }
            }
            catch (Exception e)
            {
                return StatusCode(500, e.Message);
            }
        }
        [HttpPost("register")]
        public async Task<IActionResult> Register([FromBody]User model)
        {
            Console.WriteLine("In register controller");
            Console.WriteLine(model);
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest();
                }
                var (statusCode,message) = await _authService.Registration(model, model.UserRole);
                if (statusCode==1)
                {
                    Console.WriteLine(statusCode);
                    Console.WriteLine(message);
                    return Ok(new{msg=message});
                }
                else
                {
                    return StatusCode(400, message);
                }
            }
            catch (Exception e)
            {
                return StatusCode(500, e.Message);
            }
            return CreatedAtAction(nameof(Register), model);
        }

    }
}
