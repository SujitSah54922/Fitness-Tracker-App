using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using dotnetapp.Models;
using dotnetapp.Data;
using dotnetapp.Exceptions;
//using Internal;

namespace dotnetapp.Services
{
    public class WorkoutService
    {
        private readonly ApplicationDbContext _context;

        public WorkoutService(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<Workout>> GetAllWorkouts()
        {
            return await _context.Workouts.ToListAsync();
        }

        public async Task<Workout> GetWorkoutById(int workoutId)
        {
            return await _context.Workouts.FirstOrDefaultAsync(r => r.WorkoutId == workoutId);
        }

        public async Task<bool> AddWorkout(Workout workout)
        {
            if (await _context.Workouts.AnyAsync(w => w.WorkoutName == workout.WorkoutName))
            {
                var innerException = new Exception();
                throw new WorkoutException("Workout with the same name already exists",innerException);
            }
            _context.Workouts.Add(workout);
            return await _context.SaveChangesAsync() > 0;
        }

        public async Task<bool> UpdateWorkout(int workoutId, Workout workout)
        {
            var existingWorkout = await _context.Workouts.FirstOrDefaultAsync(w => w.WorkoutId == workoutId);
            if (existingWorkout == null)
            {
                return false;
            }

            if (await _context.Workouts.AnyAsync(w => w.WorkoutName == workout.WorkoutName && w.WorkoutId != workoutId))
            {
                
                throw new WorkoutException("Workout with the same name already exists");
            }

            existingWorkout.WorkoutName = workout.WorkoutName;
            existingWorkout.Description = workout.Description;
            existingWorkout.DifficultyLevel = workout.DifficultyLevel;
            existingWorkout.CreatedAt = workout.CreatedAt;
            existingWorkout.TargetArea = workout.TargetArea;
            existingWorkout.DaysPerWeek = workout.DaysPerWeek;
            existingWorkout.AverageWorkoutDurationInMinutes = workout.AverageWorkoutDurationInMinutes;

            return await _context.SaveChangesAsync() > 0;
        }

        public async Task<bool> DeleteWorkout(int workoutId)
        {
            var workout = await _context.Workouts.FirstOrDefaultAsync(w => w.WorkoutId == workoutId);
            if (workout == null)
            {
                return false;
            }

            _context.Workouts.Remove(workout);
            return await _context.SaveChangesAsync() > 0;
        }
    }
}
