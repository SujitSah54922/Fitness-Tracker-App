using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using dotnetapp.Models;
using dotnetapp.Data;

namespace dotnetapp.Services
{
    public class WorkoutRequestService
    {
        private readonly ApplicationDbContext _context;

        public WorkoutRequestService(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<WorkoutRequest>> GetAllWorkoutRequests()
        {
            return await _context.WorkoutRequests.Include(wr => wr.User).Include(wr => wr.Workout).ToListAsync();
        }

        public async Task<bool> AddWorkoutRequest(WorkoutRequest workoutRequest)
        {
            _context.WorkoutRequests.Add(workoutRequest);
            return await _context.SaveChangesAsync() > 0;
        }

        public async Task<bool> UpdateWorkoutRequest(int workoutRequestId, WorkoutRequest workoutRequest)
        {
            var existingRequest = await _context.WorkoutRequests.FirstOrDefaultAsync(r => r.WorkoutRequestId == workoutRequestId);
            if (existingRequest == null)
            {
                return false;
            }

            existingRequest.Age = workoutRequest.Age;
            existingRequest.BMI = workoutRequest.BMI;
            existingRequest.Gender = workoutRequest.Gender;
            existingRequest.DietaryPreferences = workoutRequest.DietaryPreferences;
            existingRequest.MedicalHistory = workoutRequest.MedicalHistory;
            existingRequest.RequestedDate = workoutRequest.RequestedDate;
            existingRequest.RequestStatus = workoutRequest.RequestStatus;

            return await _context.SaveChangesAsync() > 0;
        }

        public async Task<bool> DeleteWorkoutRequest(int workoutRequestId)
        {
            var workoutRequest = await _context.WorkoutRequests.FirstOrDefaultAsync(r => r.WorkoutRequestId == workoutRequestId);
            if (workoutRequest == null)
            {
                return false;
            }

            _context.WorkoutRequests.Remove(workoutRequest);
            return await _context.SaveChangesAsync() > 0;
        }

        public async Task<IEnumerable<WorkoutRequest>> GetWorkoutRequestsByUserId(string userId)
        {
            return await _context.WorkoutRequests.Include(wr => wr.User).Include(wr => wr.Workout).Where(wr => wr.UserId == userId).ToListAsync();
        }
    }
}
