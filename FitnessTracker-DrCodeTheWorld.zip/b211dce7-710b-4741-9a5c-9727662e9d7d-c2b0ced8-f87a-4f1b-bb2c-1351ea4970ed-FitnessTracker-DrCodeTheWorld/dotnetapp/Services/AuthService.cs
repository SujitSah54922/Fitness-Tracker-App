using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity;
using System.IdentityModel.Tokens.Jwt;
using Microsoft.IdentityModel.Tokens;
using Microsoft.Extensions.Configuration;
using System.Collections.Generic;
using System.Security.Claims;
using System.Threading.Tasks;
using dotnetapp.Models;
using dotnetapp.Data;
//using Internal;
//using Internal;

namespace dotnetapp.Services
{
    public class AuthService : IAuthService
    {
       private readonly UserManager<ApplicationUser> _userManager;
        private readonly RoleManager<IdentityRole> _roleManager;
        private readonly IConfiguration _configuration;
        private readonly ApplicationDbContext _context;
 
        public AuthService(UserManager<ApplicationUser> userManager, RoleManager<IdentityRole> roleManager, IConfiguration configuration, ApplicationDbContext context)
        {
            _userManager = userManager;
            _roleManager = roleManager;
            _configuration = configuration;
            _context = context;
        }
 
        public async Task<(int, string)> Registration(User model, string role)
        {
            Console.WriteLine("Enter Register");
            model.UserId="1";
            // Check if user already exists
            var existingUser = await _userManager.FindByEmailAsync(model.Email);
            if (existingUser != null)
            {
                return (0, "User already exists");
            }
            ApplicationUser user = new ApplicationUser()
            {
                Email = model.Email,
                UserName = model.Username,
                Name = model.Username,
                PhoneNumber = model.MobileNumber,
                Role = model.UserRole,
                SecurityStamp = System.Guid.NewGuid().ToString()
            };
            var result = await _userManager.CreateAsync(user, model.Password);
            Console.WriteLine(result);

            if (!result.Succeeded)
            {
 
                return (0, "User creation failed! Please check user details and try again.");
            }
                var userId="";
                var user1 = await _userManager.FindByEmailAsync(model.Email);
                if(user1!=null)
                {
                    userId = user1.Id;
                }
            Console.WriteLine(userId);
 
            if (!await _roleManager.RoleExistsAsync(role))
            {
                await _roleManager.CreateAsync(new IdentityRole(role));
            }
 
            if (await _roleManager.RoleExistsAsync(role))
            {
                await _userManager.AddToRoleAsync(user, role);
            }
            //Console.WriteLine(result);
 
            // if (!result.Succeeded)
            // {
 
            //     return (0, "User creation failed! Please check user details and try again.");
            // }
            User newUser = new User()
            {
                UserId = userId,
                Email = model.Email,
                Password = model.Password,
                Username = model.Username,
                MobileNumber = model.MobileNumber,
                UserRole = model.UserRole,
            };
 
            // Create new user
            // model.UserRole = role;
            _context.Users.Add(newUser);
            await _context.SaveChangesAsync();
 
            return (1, "User registered successfully");
        }
        public async Task<(int, string)> Login(LoginModel model)
        {
            Console.WriteLine("InLoginService");
            var user = await _userManager.FindByEmailAsync(model.Email);
            Console.WriteLine(user);
            if (user == null)
            {
                return (0, "Invalid email");
            }
 
            if (!await _userManager.CheckPasswordAsync(user, model.Password))
            {
                return (0, "Invalid password");
            }
 
            var userRoles = await _userManager.GetRolesAsync(user);
            var authClaims = new List<Claim>
            {
                new Claim(ClaimTypes.Name, user.UserName),
                new Claim(ClaimTypes.Role, user.Role),
                new Claim(ClaimTypes.NameIdentifier, user.Id),
                
                new Claim(JwtRegisteredClaimNames.Jti, System.Guid.NewGuid().ToString())
            };
 
            // foreach (var userRole in userRoles)
            // {
            //     authClaims.Add(new Claim(ClaimTypes.Role, userRole));
            // }
 
            var token = GenerateToken(authClaims);
            return (1, token);
 
        }
        private string GenerateToken(IEnumerable<Claim> claims)
        {
            Console.WriteLine("In generate token");
            var key = new SymmetricSecurityKey(System.Text.Encoding.UTF8.GetBytes(_configuration["Jwt:Secret"]));
            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);
 
            var token = new JwtSecurityToken(
                _configuration["Jwt:Issuer"],
                _configuration["Jwt:ValidAudience"],
                claims,
                expires: DateTime.Now.AddMinutes(30),
                signingCredentials: creds);
 
            return new JwtSecurityTokenHandler().WriteToken(token);
        }
    }
}