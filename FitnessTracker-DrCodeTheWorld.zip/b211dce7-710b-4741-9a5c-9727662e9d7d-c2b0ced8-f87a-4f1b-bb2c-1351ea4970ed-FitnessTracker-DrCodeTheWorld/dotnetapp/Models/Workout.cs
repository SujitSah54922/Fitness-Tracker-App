using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace dotnetapp.Models
{
    public class Workout
    {
        [Key]
        public int WorkoutId { get; set; }
        public string WorkoutName { get; set; }
        public string Description { get; set; }
        public int DifficultyLevel { get; set; }
        public DateTime CreatedAt { get; set; }
        public string TargetArea { get; set; }
        public int DaysPerWeek { get; set; }
        public int AverageWorkoutDurationInMinutes { get; set; }
    }
}