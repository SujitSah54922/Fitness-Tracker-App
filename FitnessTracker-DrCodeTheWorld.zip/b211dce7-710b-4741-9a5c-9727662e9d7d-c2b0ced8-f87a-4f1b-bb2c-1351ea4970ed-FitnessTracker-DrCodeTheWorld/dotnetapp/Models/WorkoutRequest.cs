using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace dotnetapp.Models
{
    public class WorkoutRequest
    {
        [Key]
        public int WorkoutRequestId { get; set; }
        public int Age { get; set; }
        public double BMI { get; set; }
        public string Gender { get; set; }
        public string DietaryPreferences { get; set; }
        public string MedicalHistory { get; set; }
        public DateTime RequestedDate { get; set; }
        public string RequestStatus { get; set; }
        public string UserId { get; set; }
        //[JsonIgnore]
        public User? User { get; set; }
        public int WorkoutId { get; set; }
        //[JsonIgnore]
        public Workout? Workout { get; set; }
    }
}