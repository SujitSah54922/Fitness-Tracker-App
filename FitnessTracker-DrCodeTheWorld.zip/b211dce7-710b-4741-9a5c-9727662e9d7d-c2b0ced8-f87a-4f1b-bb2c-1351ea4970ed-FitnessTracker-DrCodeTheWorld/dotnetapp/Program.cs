    using Microsoft.AspNetCore.Authentication.JwtBearer;
    using Microsoft.IdentityModel.Tokens;
    using System.Text;
    using Microsoft.EntityFrameworkCore;
    using dotnetapp.Data;
    using Microsoft.AspNetCore.Identity;
    using dotnetapp.Services;
    using dotnetapp.Models;
    using Microsoft.OpenApi.Models;
    using System.Text.Json.Serialization;
    using System.Text.Json;
    using Newtonsoft.Json;
    using Microsoft.AspNetCore.Mvc.NewtonsoftJson;
    using Newtonsoft.Json.Serialization;


    var builder = WebApplication.CreateBuilder(args);
    
    // Add services to the container.

    // builder.Services.AddControllers();

    // builder.Services.AddControllers()
    // .AddJsonOptions(options =>{
    // options.JsonSerializerOptions.ReferenceHandler = ReferenceHandler.IgnoreCycles;
    // options.JsonSerializerOptions.WriteIndented = true;
    // });
    builder.Services.AddControllers().AddNewtonsoftJson(options =>
   {
       options.SerializerSettings.ContractResolver = new DefaultContractResolver
       {
           NamingStrategy = new CamelCaseNamingStrategy()
       };
   });


    builder.Services.AddDbContext<ApplicationDbContext>(p=>{
        p.UseSqlServer(builder.Configuration.GetConnectionString("conn"));
    });

    builder.Services.AddMvc()
        .AddJsonOptions(options => options.JsonSerializerOptions.PropertyNamingPolicy = null)
        .AddJsonOptions(options=> options.JsonSerializerOptions.ReferenceHandler= ReferenceHandler.IgnoreCycles);
    
    
    builder.Services.AddIdentity<ApplicationUser, IdentityRole>()
        .AddEntityFrameworkStores<ApplicationDbContext>()
        .AddDefaultTokenProviders();
    builder.Services.AddEndpointsApiExplorer();
    builder.Services.AddSwaggerGen();

    builder.Services.AddScoped<AuthService>();
    builder.Services.AddScoped<FeedbackService>();
    builder.Services.AddScoped<IAuthService, AuthService>(); // Register the interface with its implementation
    builder.Services.AddScoped<WorkoutRequestService>();
    builder.Services.AddScoped<WorkoutService>();
    

    // Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
    //importing CORS
    builder.Services.AddCors(p => p.AddPolicy("corsapp", builder =>
   {
       builder.AllowAnyOrigin().AllowAnyMethod().AllowAnyHeader();
   }));
    //Configuring JWT Token for authentication
    var jwtSettings = builder.Configuration.GetSection("JWT");
    builder.Services.AddAuthentication(options =>
    {
        options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
        options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
    })
    .AddJwtBearer(options =>
    {
        options.TokenValidationParameters = new TokenValidationParameters
        {
            ValidateIssuer = false,
            ValidateAudience = false,
            ValidateLifetime = true,
            ValidateIssuerSigningKey = true,
            // ValidIssuer = jwtSettings["ValidIssuer"],
            // ValidAudience = jwtSettings["ValidAudience"],
            IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwtSettings["Secret"]))
        };
    });

    //Swagger Authentication
    builder.Services.AddSwaggerGen(options => 
    {
        options.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
        {
            Scheme = "Bearer",
            BearerFormat = "JWT",
            In = ParameterLocation.Header,
            Name = "Authorization",
            Description = "Bearer Authentication with JWT Token",
            Type = SecuritySchemeType.Http
        });
        options.AddSecurityRequirement(new OpenApiSecurityRequirement
        {
            {
                new OpenApiSecurityScheme
                {
                    Reference = new OpenApiReference
                    {
                        Id = "Bearer",
                        Type = ReferenceType.SecurityScheme
                    }
                },
                new List<string>()
            }
        });
    });
    
    //builder.Services.AddAuthorization();
    
    var app = builder.Build();
    
    // Configure the HTTP request pipeline.
    if (app.Environment.IsDevelopment())
    {
        app.UseSwagger();
        app.UseSwaggerUI();
    }
    
    app.UseCors("corsapp");
    app.UseAuthentication();
    app.UseAuthorization();
    app.UseHttpsRedirection();
    
    app.MapControllers();
    app.Run();