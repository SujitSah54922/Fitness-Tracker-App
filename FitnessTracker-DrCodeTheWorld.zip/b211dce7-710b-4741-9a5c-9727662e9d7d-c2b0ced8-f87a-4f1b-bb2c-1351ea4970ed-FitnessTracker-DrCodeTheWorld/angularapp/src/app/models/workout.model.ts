export class Workout {

    workoutId?: number;
    
    workoutName: string;
    
    description: string;
    
    difficultyLevel: number;
    
    createdAt: Date;
    
    targetArea: string;
    
    daysPerWeek: number;
    
    averageWorkoutDurationInMinutes: number;
    
    }