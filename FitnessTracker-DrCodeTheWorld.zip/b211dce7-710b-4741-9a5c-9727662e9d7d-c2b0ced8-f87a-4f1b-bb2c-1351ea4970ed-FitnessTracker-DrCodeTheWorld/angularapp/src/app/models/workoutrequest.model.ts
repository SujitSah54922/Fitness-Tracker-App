import { Workout } from "./workout.model";
export interface WorkoutRequest {

    workoutRequestId?: number;
    
    userId?: string;
    
    workoutId?: number;
    workout?: Workout;
    
    age: number;
    
    bmi: number;
    
    gender: string;
    
    dietaryPreferences: string;
    
    medicalHistory: string;
    
    requestedDate: Date;
    
    requestStatus: string;
    
    }