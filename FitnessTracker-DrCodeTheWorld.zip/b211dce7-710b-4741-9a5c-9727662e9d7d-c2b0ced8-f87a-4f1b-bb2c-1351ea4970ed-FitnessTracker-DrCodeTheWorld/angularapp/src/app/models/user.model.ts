export interface User{
    userId?: string;

    email: string;

    password: string;

    username: string;

    mobileNumber: string;

    userRole:('Admin' | 'User');
    //UserRole: string;
}