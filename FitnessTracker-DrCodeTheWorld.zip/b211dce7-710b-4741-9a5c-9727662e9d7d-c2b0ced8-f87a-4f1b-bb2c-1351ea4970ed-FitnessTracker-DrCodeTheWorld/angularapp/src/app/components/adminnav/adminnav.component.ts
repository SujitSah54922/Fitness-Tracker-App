import { Component, OnInit } from '@angular/core';
import { AuthService } from 'src/app/services/auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-adminnav',
  templateUrl: './adminnav.component.html',
  styleUrls: ['./adminnav.component.css']
})
export class AdminnavComponent implements OnInit {
  dropdownOpen = false;

  constructor(private service: AuthService, private route: Router) { }

  ngOnInit(): void {
  }
  toggleDropdown() {
    this.dropdownOpen = !this.dropdownOpen;
  }
  logout(){
    this.service.logout();
    this.route.navigate(['/login']);
  }

}
