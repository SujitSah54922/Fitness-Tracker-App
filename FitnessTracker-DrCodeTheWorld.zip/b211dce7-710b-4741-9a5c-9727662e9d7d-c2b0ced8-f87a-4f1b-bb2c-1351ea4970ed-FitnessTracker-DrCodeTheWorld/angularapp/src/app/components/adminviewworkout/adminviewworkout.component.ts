import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Workout } from 'src/app/models/workout.model';
import { WorkoutService } from 'src/app/services/workout.service';
 
@Component({
  selector: 'app-adminviewworkout',
  templateUrl: './adminviewworkout.component.html',
  styleUrls: ['./adminviewworkout.component.css']
})
export class AdminviewworkoutComponent implements OnInit {
  searchText: string = '';
  workoutList: Workout[] = [];
  showPopup:boolean=false;
  deleteId:number;
  loadSpinner:boolean = false;// fro load spinner 
  constructor (private service: WorkoutService,private route:Router) { }
 
  ngOnInit(): void {
    this.getWorkouts();
  }
      // Add more workout objects as needed
 
  getWorkouts() {
    this.service.getAllWorkouts().subscribe((data) => {
      this.loadSpinner = true;
      this.workoutList = data;
    });
  }
  onSearch() {
    if (this.searchText) {
      this.loadSpinner = false;
      this.workoutList = this.workoutList.filter(item =>
        item.workoutName.toLowerCase().includes(this.searchText.toLowerCase())
      );
      this.loadSpinner = true;
    } else {
      this.loadSpinner = false;
      this.getWorkouts();
    }
  }
 
  editWorkout(id: number) {
    // Implement edit workout logic here
    // console.log('Edit workout with id:', id);
    this.route.navigate([`editAdminWorkout/${id}`])
    
  }
 
  deleteWorkout(id: number) {
    // Implement delete workout logic here
    // this.workoutService.deleteWorkout(id).subscribe(() => {
    //   this.getWorkouts();
    // });
    // console.log('Delete workout with id:', id);
    this.service.deleteWorkout(id).subscribe((data)=>{
    this.showPopup = false;
    this.getWorkouts();
  });

  }
  openPopup(index: number) {
    this.deleteId = index;
    console.log(this.deleteId);
    this.showPopup = true;
  }

  closePopup() {
    this.showPopup = false;
  }


 
}
 