import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, NgForm, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { User } from 'src/app/models/user.model';
import { AuthService } from 'src/app/services/auth.service';


@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {
  //registrationForm=NgForm;
  errorMessage: string = '';

  user: User = {
    email: '',
    password: '',
    username: '',
    mobileNumber: '',
    userRole: 'Admin'
  }


  constructor(private authService: AuthService, private router: Router) {

  }
  ngOnInit(): void {
  }

  onSubmit(form: NgForm) {
    if (form.valid) {
      console.log("After from.isValid in registration.ts");
      console.log(this.user);
      this.authService.register(this.user).subscribe((data) => {
      console.log("In Subscribe.... Registration component ")
      this.router.navigate([`/login`])
      });
    }
  }
}