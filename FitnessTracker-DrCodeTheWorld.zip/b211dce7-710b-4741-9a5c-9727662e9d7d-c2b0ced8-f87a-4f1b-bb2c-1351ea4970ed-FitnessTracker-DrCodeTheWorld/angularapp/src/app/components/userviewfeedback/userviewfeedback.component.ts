import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Feedback } from 'src/app/models/feedback.model';
import { FeedbackService } from 'src/app/services/feedback.service';
 
@Component({
  selector: 'app-userviewfeedback',
  templateUrl: './userviewfeedback.component.html',
  styleUrls: ['./userviewfeedback.component.css']
})
export class UserviewfeedbackComponent implements OnInit {
  feedbackList:Feedback[]=[];
  deleteId:number;
  showPopup:boolean=false;
  loadSpinner:boolean = false;// fro load spinner 
 
 
  constructor(private feedbackService:FeedbackService,private route:Router) { }
  
  ngOnInit(): void {
    this.getAllFeedbacks();
  }
  editFeedback(feedback) {
    // Logic to edit feedback
  }
  getAllFeedbacks()
  {
     this.feedbackService.getFeedbacks().subscribe((data)=>
     {
      this.loadSpinner = true;
     console.log(data)
     this.feedbackList=data
  })
  }
 
 
  deleteFeedback() {
    this.feedbackService.deleteFeedback(this.deleteId).subscribe((data)=>{
      // this.loadSpinner = true;
      this.closePopup()
      this.getAllFeedbacks()
  })
  }
  openPopup(index: number) {
    this.deleteId = index;
    this.showPopup = true;
    //this.deleteFeedback(this.deleteId);
  }

  closePopup() {
    this.showPopup = false;
  }
 
}
