import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { Workout } from 'src/app/models/workout.model';
import { WorkoutService } from 'src/app/services/workout.service';


@Component({
  selector: 'app-adminaddworkout',
  templateUrl: './adminaddworkout.component.html',
  styleUrls: ['./adminaddworkout.component.css']
})
export class AdminaddworkoutComponent implements OnInit {

  constructor(private workoutService: WorkoutService, private route: Router) { }

  ngOnInit(): void {
  }
  showPopup:boolean=false;
  
  workout:Workout={
    workoutName: "",

    description: "",

    difficultyLevel: 1,

    createdAt: new Date(),

    targetArea: "",

    daysPerWeek: 0,

    averageWorkoutDurationInMinutes: 0,

  }
  openPopup() {
    this.showPopup = true;
  }

  closePopup() {
    this.showPopup = false;
    this.route.navigate([`adminViewWorkouts`]);
  }
  onSubmit(form:NgForm) {
    if (form.valid) {
      // Perform your form submission logic here
      // if (this.workout.WorkoutName !== "" && this.workout.Description !== "" &&
      //   this.workout.DifficultyLevel > 0 && this.workout.CreatedAt !== "" &&
      //   this.workout.TargetArea !== "" && this.workout.DaysPerWeek > 0 &&
      //   this.workout.AverageWorkoutDurationInMinutes > 0) {

        this.workoutService.addWorkout(this.workout).subscribe(
          data => {
            
            // Show popup after successful addition
            this.showPopup = true;
            console.log("WorkOut Added successfully!!!");
            setTimeout(() => {
              this.showPopup = false;
              form.resetForm(); // Reset form after hiding popup
            }, 200000000000000); // Hide popup after 2 seconds
          },
          error => {
            // Handle error if needed
            console.error("Error adding workout:", error);
          }
        );
    }
  }



}
