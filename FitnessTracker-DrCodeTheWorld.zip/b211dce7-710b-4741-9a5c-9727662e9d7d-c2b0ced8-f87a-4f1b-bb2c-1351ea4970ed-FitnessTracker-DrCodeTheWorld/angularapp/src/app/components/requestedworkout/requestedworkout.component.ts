import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { WorkoutRequest } from 'src/app/models/workoutrequest.model';
import { WorkoutrequestService } from 'src/app/services/workoutrequest.service';

 
@Component({
  selector: 'app-requestedworkout',
  templateUrl: './requestedworkout.component.html',
  styleUrls: ['./requestedworkout.component.css']
})
export class RequestedworkoutComponent implements OnInit {
 
  constructor (private service: WorkoutrequestService,private route:Router) { }

  loadSpinner:boolean = false;// fro load spinner 
  searchText: string = '';

  ngOnInit(): void {
    this.getWorkoutRequest();
    
  }
  workoutRequests : any[]=[];
  getWorkoutRequest()
  {
    this.service.getAllWorkoutRequests().subscribe(data=>{
      this.loadSpinner = true;
      this.workoutRequests=data;
      
    })
  }



  selectedRequest: any = null;

  showDetails(request: any) {
    this.selectedRequest = request;
  }

  closeDetails() {
    this.selectedRequest = null;
  }

  approveRequest(requestId: number) {
    const request = this.workoutRequests.find(req => req.workoutRequestId === requestId);
    //console.log(request);
    if (request) {
      request.requestStatus = 'Approved';
      this.service.updateWorkoutStatus(request.workoutRequestId,request).subscribe(data=>{
        console.log(request);
      })
    }
  }

  rejectRequest(requestId: number) {
    console.log("Button operated");
    const request = this.workoutRequests.find(req => req.workoutRequestId === requestId);
    //console.log(request);
    if (request) {
      request.requestStatus = 'Rejected';
      this.service.updateWorkoutStatus(requestId,request).subscribe(data=>{
        
      })
    }
  }

  onSearch() {
    if (this.searchText) {
      this.loadSpinner = false;
      this.workoutRequests = this.workoutRequests.filter(item =>
        item.workout.workoutName.toLowerCase().includes(this.searchText.toLowerCase())
      );
      this.loadSpinner = true;
    } else {
      this.loadSpinner = false;
      this.getWorkoutRequest();
    }
  }
 
}