import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { WorkoutService } from 'src/app/services/workout.service';
import { Workout } from 'src/app/models/workout.model';
import { WorkoutRequest } from 'src/app/models/workoutrequest.model';
import { WorkoutrequestService } from 'src/app/services/workoutrequest.service';

@Component({
  selector: 'app-userviewworkout',
  templateUrl: './userviewworkout.component.html',
  styleUrls: ['./userviewworkout.component.css']
})
export class UserviewworkoutComponent implements OnInit {
  workoutList: Workout[] = [];
  workoutRequestList:WorkoutRequest[];
  showPopup:boolean=false;
  deleteId:number;
  loadSpinner:boolean = false;// fro load spinner 
  searchText: string = '';
  constructor (private workoutService: WorkoutService,private workoutRequest:WorkoutrequestService, private route:Router) { }

  ngOnInit(): void {

    this.getWorkouts();
    this.getAllAppliedWorkoutByUser();
  }
  getWorkouts() {

    this.workoutService.getAllWorkouts().subscribe((data) => {
      this.loadSpinner = true;
      this.workoutList = data;
    });
  }
  getAllAppliedWorkoutByUser()
  {
    this.workoutRequest.getAppliedWorkouts(localStorage.getItem('UserId')).subscribe((data)=>{
      this.loadSpinner = true;// will be true unless data is recived
      console.log(data);
      this.workoutRequestList=data;
  })
  }
  disableApplyButton(Id:number):boolean
  {
    if (!this.workoutRequestList) {
      return false; // or handle the undefined case as needed
    }
    return this.workoutRequestList.some(w => w.workoutId === Id)
  }
  onSearch() {
    if (this.searchText) {
      this.loadSpinner = false;
      this.workoutList = this.workoutList.filter(item =>
        item.workoutName.toLowerCase().includes(this.searchText.toLowerCase())
      );
      this.loadSpinner = true;
    } else {
      this.loadSpinner = false;
      this.getWorkouts();
    }
  }
  applyWorkout(workoutId:number) {
    
    // Implement edit workout logic here

    console.log();
    this.route.navigate([`/user/applyform/${workoutId}`]);
  }

  // filterWorkouts(): void {
  //   this.filteredWorkouts = this.workouts.filter(workout =>
  //     workout.name.toLowerCase().includes(this.searchText.toLowerCase())
  //   );
  // }

  
}


