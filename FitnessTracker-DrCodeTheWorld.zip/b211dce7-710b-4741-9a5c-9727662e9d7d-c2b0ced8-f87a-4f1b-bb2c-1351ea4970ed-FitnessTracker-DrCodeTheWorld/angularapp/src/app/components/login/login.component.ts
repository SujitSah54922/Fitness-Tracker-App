import { Component, OnInit } from '@angular/core';
import { Login } from 'src/app/models/login.model';
import { NgForm } from '@angular/forms';
import { AuthService } from 'src/app/services/auth.service';
import { Router } from '@angular/router';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  userLogin: Login={
    Email:'',
    Password:''
  }
  role: string='';
  loadSpinner:boolean = false;// fro load spinner 

  constructor(private authService:AuthService, private router:Router) { }

  ngOnInit(): void {
  }
  login()
  {
    this.loadSpinner = true;
    this.authService.login(this.userLogin).subscribe(()=>{
      //console.log(this.userLogin);
      console.log("Log in Succesfully in ts file");
      this.role=localStorage.getItem('userRole').toLowerCase();
      console.log('This is roles:'+ this.role);
      this.router.navigate([`${this.role}`]);
      this.loadSpinner = false;
    });
  }

}
