import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { Feedback } from 'src/app/models/feedback.model';
import { FeedbackService } from 'src/app/services/feedback.service';
 
@Component({
  selector: 'app-useraddfeedback',
  templateUrl: './useraddfeedback.component.html',
  styleUrls: ['./useraddfeedback.component.css']
})
export class UseraddfeedbackComponent implements OnInit {
  showPopup:boolean=false;
  feedBack:Feedback=
  {
    feedbackId:0,
    
    userId: '',
    
    feedbackText: '',
    
    date: new Date(),
  };
 
  constructor(private service: FeedbackService,private route:Router) { }
 
  ngOnInit(): void {

  }
  onSubmit(form:NgForm) {

    if (form.valid) {
      this.feedBack.userId=localStorage.getItem('UserId')
      console.log("inOnSubmit");
      console.log(this.feedBack);
      this.service.sendFeedback(this.feedBack).subscribe((date)=>{
      console.log("AfterEnteringService")
        this.openPopup()
    })
    }
  }
  openPopup(){
    // console.log(this.deleteId);
    this.showPopup = true;
    
  }

  closePopup(){
    this.showPopup = false;
    this.route.navigate(['userviewFeedback'])
  }
 
}
