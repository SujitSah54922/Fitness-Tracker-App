
import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { WorkoutRequest } from 'src/app/models/workoutrequest.model';
import { WorkoutrequestService } from 'src/app/services/workoutrequest.service';

@Component({
  selector: 'app-userworkoutform',
  templateUrl: './userworkoutform.component.html',
  styleUrls: ['./userworkoutform.component.css']
})
export class UserworkoutformComponent implements OnInit {

  showPopup:boolean = false;
  workoutRequest: WorkoutRequest={
  workoutRequestId:0,
  userId: '', 
  workoutId: 0,
  age: 0,
  bmi: 0,
  gender: '',
  dietaryPreferences: '', 
  medicalHistory: '',
  requestedDate: new Date(),
  requestStatus: ''
  };
  

  constructor(private workoutRequestService:WorkoutrequestService,private route:Router, private activatedRoute: ActivatedRoute) { }

  ngOnInit(): void {

    this.activatedRoute.params.subscribe((data)=>{
      this.workoutRequest.workoutId=data.workId
    })
  }
  onSubmit(form:NgForm) {

    this.workoutRequest.requestedDate=new Date();
    this.workoutRequest.requestStatus = 'Pending';
    this.workoutRequest.userId= localStorage.getItem('UserId');
    if(form.valid) {

      //console.log(this.workoutRequest);

      this.workoutRequestService.addWorkoutRequest(this.workoutRequest).subscribe((data)=>{
        console.log('inside addWordOut service post section.');
        this.openPopup()
      });
      
    }
  }

  openPopup() {

    this.showPopup = true;
  }
  closePopup() {
    
    this.showPopup = false;
    this.route.navigate([`userappliedworkout`]);
  }
}
