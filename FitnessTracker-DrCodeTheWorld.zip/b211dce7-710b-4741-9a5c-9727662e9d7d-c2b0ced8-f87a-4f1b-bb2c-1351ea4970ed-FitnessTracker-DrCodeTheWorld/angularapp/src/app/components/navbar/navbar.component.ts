import { Component, OnInit } from '@angular/core';
import { Login } from 'src/app/models/login.model';
import { AuthService } from 'src/app/services/auth.service';
import { Router } from '@angular/router';
//import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit {

  constructor(private service: AuthService, private route: Router) { }

  ngOnInit(): void {
  }
  isUser() {
    //console.log(this.service.isUser());
    return this.service.isUser();
  }

  isAdmin() {
    return this.service.isAdmin();
  }

  isLoggedIn() {
    return this.service.isLoggedIn();
  }

  logout() {
    this.service.logout();
    this.route.navigate(['/login']);
  }

}
