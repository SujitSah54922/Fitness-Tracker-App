import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Workout } from 'src/app/models/workout.model';
import { WorkoutService } from 'src/app/services/workout.service';
@Component({
  selector: 'app-admineditworkout',
  templateUrl: './admineditworkout.component.html',
  styleUrls: ['./admineditworkout.component.css']
})
export class AdmineditworkoutComponent implements OnInit {

  loadSpinner:boolean = false;// fro load spinner 
  workout: Workout = 
  {
    workoutName: '',
    description: '',
    difficultyLevel: 0,
    createdAt: new Date(),
    targetArea: '',
    daysPerWeek: 0,
    averageWorkoutDurationInMinutes:0
  };
  // workoutName:string;
  // description:string;
  // difficultyLevel:number;
  // createdAt:Date;
  // targetArea:string;
  // daysPerWeek:number;
  // averageWorkoutDurationInMinutes:number;
  showPopup: boolean = false;
  id:number;
  constructor(
    private activatedRouted: ActivatedRoute,
    private router: Router,
    private workoutService: WorkoutService
  ) {}

  ngOnInit(): void {
    //getting Id using params
    this.activatedRouted.params.subscribe(data => {
      this.loadSpinner = true;
      this.id = data.id;
      console.log(this.id);
      this.getWorkoutDetails(this.id);
    });
  }

  getWorkoutDetails(id: number): void {
    this.workoutService.getWorkoutById(id).subscribe(
      (data) => {
        this.workout = data;
        console.log(this.workout);
      },
      (error: any) => {
        console.error('Error fetching workout details', error);
      }
    );
  }

  onSubmit(form): void {
    if (form.valid) {
      this.workoutService.updateWorkout(this.id,this.workout).subscribe(
        (response: any) => {
          this.showPopup = true;
        },
        (error: any) => {
          console.error('Error updating workout', error);
        }
      );
    }
  }

  closePopup(): void {
    this.showPopup = false;
    this.router.navigate([`adminViewWorkouts`]); // Navigate to the workouts list or another appropriate route
  }
      

}
