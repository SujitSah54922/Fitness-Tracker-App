import { Component, OnInit } from '@angular/core';
import { Feedback } from 'src/app/models/feedback.model';
import { FeedbackService } from 'src/app/services/feedback.service';

@Component({
  selector: 'app-adminviewfeedback',
  templateUrl: './adminviewfeedback.component.html',
  styleUrls: ['./adminviewfeedback.component.css']
})
export class AdminviewfeedbackComponent implements OnInit {

  constructor(private feedBackService: FeedbackService) { }
  feedbackList: Feedback[];
  selectedFeedback: any = null;
  loadSpinner:boolean = false;// fro load spinner 

  ngOnInit(): void {
    this.getFeedBack();
  }
  getFeedBack() {
    this.feedBackService.getFeedbacks().subscribe((data) => {
      this.loadSpinner = true;
      this.feedbackList = data;
      console.log(data)
    })
  }
  showProfile(feedBack: Feedback) {
    this.selectedFeedback = feedBack;
  }

  closeProfile() {
    this.selectedFeedback = false;
  }


}
