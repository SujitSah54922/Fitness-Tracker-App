import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Workout } from 'src/app/models/workout.model';
import { WorkoutRequest } from 'src/app/models/workoutrequest.model';
import { WorkoutService } from 'src/app/services/workout.service';
import { WorkoutrequestService } from 'src/app/services/workoutrequest.service';

@Component({
  selector: 'app-userappliedworkout',
  templateUrl: './userappliedworkout.component.html',
  styleUrls: ['./userappliedworkout.component.css']
})
export class UserappliedworkoutComponent implements OnInit {

  workoutRequestList:WorkoutRequest[];
  showPopup:boolean=false;
  deleteId:number;
  loadSpinner:boolean = false;// fro load spinner 
  searchText: string = '';
  constructor(private workoutRequest:WorkoutrequestService,private workout:WorkoutService,private route:Router) { }

  ngOnInit(): void {

    this.getWorkoutRequest();

  }
  getWorkoutRequest()
  {
    this.workoutRequest.getAppliedWorkouts(localStorage.getItem('UserId')).subscribe((data)=>{
      this.loadSpinner = true;// will be true unless data is recived
      //console.log(data);
      this.workoutRequestList=data;
  })
  
  }
  // getWorkoutName(workoutID:number):string
  // {
  //   let workoutName:string;
  //   this.workout.getWorkoutById(workoutID).subscribe((data)=>{
  //     workoutName = data.workoutName;
  //   })
  //   return workoutName;
  // }

  onSearch() {
    if (this.searchText) {
      this.loadSpinner = false;
      this.workoutRequestList = this.workoutRequestList.filter(item =>
        item.workout.workoutName.toLowerCase().includes(this.searchText.toLowerCase())
      );
      this.loadSpinner = true;
    } else {
      this.loadSpinner = false;
      this.getWorkoutRequest();
    }
  }

  deleteWorkout(WorkoutRequestId:number) {

    this.workoutRequest.deleteWorkoutApplication(WorkoutRequestId).subscribe((data)=>{

      this.getWorkoutRequest()
      this.closePopup()
  })
    // if (workout.status === 'Pending') {
    //   if (confirm('Are you sure you want to delete this workout?')) {
    //     this.workout = this.workouts.filter(w => w !== workout);
    //   }
    // }
  }
  openPopup(index: number) {

    this.deleteId = index;
    // console.log(this.deleteId);
    this.showPopup = true;
    
  }

  closePopup() {

    this.showPopup = false;
  }

}
