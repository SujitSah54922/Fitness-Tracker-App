import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, BehaviorSubject } from 'rxjs';
import { tap } from 'rxjs/operators';
import { User } from '../models/user.model';
import { Login } from '../models/login.model';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  public apiUrl = "https://8080-dadeabbedbededefdfdaedcbdcbcedfafbbbceaed.premiumproject.examly.io";

  // private userRole = new BehaviorSubject<string>(null);
  // private userId = new BehaviorSubject<string>(null);

  constructor(private http: HttpClient) {}

  // private getHeaders(): HttpHeaders {
  //   return new HttpHeaders({
  //     'Content-Type': 'pplication/json'
  //   });
  // }

  register(newUser:User):Observable<User>
  {
    console.log("Url: " + this.apiUrl);
    console.log("User: ");
    console.log(newUser);
    newUser.userId ='1';
    return this.http.post<User>(`${this.apiUrl}/api/register`,newUser);
  }

  login(loginUser:Login):Observable<any>
  {
    console.log("IN auth login service");
    return this.http.post<any>(`${this.apiUrl}/api/login`,loginUser).pipe(
      tap((response)=>{
        //console.log(response.Token);
        console.log(response);
        if(response.token && response)
        {
          console.log(response.token);
          localStorage.setItem('jwtToken',response.token);
          const tokenPart=response.token.split('.'); 
          console.log("Token Part:" + tokenPart[1]);
          let payload=JSON.parse(atob(tokenPart[1]));
          const role= "http://schemas.microsoft.com/ws/2008/06/identity/claims/role";
          //const userId = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/nameidentifier";
          const userName = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/name";
          console.log("UserID: ",payload["http://schemas.xmlsoap.org/ws/2005/05/identity/claims/nameidentifier"]);
          localStorage.setItem('UserId', payload["http://schemas.xmlsoap.org/ws/2005/05/identity/claims/nameidentifier"]); // storing user id
          console.log("PayLoad: ",payload[role]);
          localStorage.setItem('userRole',payload[role]);
          localStorage.setItem('userName',payload[userName]);  //localStorage.getItem('userRole')
         
          
        }
        else
        {
          console.log(" Not found token"); 
        }
      }
      )
    )
  }
  isLoggedIn()
  {
    if(localStorage.getItem('userRole')==='Admin' || localStorage.getItem('userRole')==='User')
    {
      return true;
    } 
    return false;
  }

  isAdmin()
  {
    return localStorage.getItem('userRole')==='Admin';
  }
  
  isUser()
  {
    return localStorage.getItem('userRole')==='User';

  }

  logout()
  {
    localStorage.clear(); 
  }



  // getUserRole(): Observable<string> {
  //   return this.userRole.asObservable();
  // }

  // getUserId(): Observable<string> {
  //   return this.userId.asObservable();
  // }
}