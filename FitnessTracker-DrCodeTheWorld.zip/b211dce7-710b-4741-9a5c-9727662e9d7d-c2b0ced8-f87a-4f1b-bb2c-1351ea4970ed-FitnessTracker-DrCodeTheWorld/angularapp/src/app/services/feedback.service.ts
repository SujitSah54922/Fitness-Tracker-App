import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Feedback } from '../models/feedback.model';

@Injectable({
  providedIn: 'root'
})
export class FeedbackService {
  public apiUrl = "https://8080-dadeabbedbededefdfdaedcbdcbcedfafbbbceaed.premiumproject.examly.io";

  constructor(private http: HttpClient) {}

  private getHeaders(): HttpHeaders {
    const token = localStorage.getItem('authToken');
    return new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`
    });
  }

  sendFeedback(feedback: Feedback): Observable<Feedback> {
    return this.http.post<Feedback>(`${this.apiUrl}/api/feedback`, feedback, { headers: this.getHeaders()});
  }

  getAllFeedbacksByUserId(userId: string): Observable<Feedback[]> {
    const url = `${this.apiUrl}/user/${userId}`;
    return this.http.get<Feedback[]>(url, { headers: this.getHeaders() });
  }

  deleteFeedback(feedbackId: number): Observable<void> {
    const url = `${this.apiUrl}/api/feedback/${feedbackId}`;
    return this.http.delete<void>(url, { headers: this.getHeaders() });
  }

  getFeedbacks(): Observable<Feedback[]> {
    return this.http.get<Feedback[]>(`${this.apiUrl}/api/feedback`, { headers: this.getHeaders() });
  }
}
