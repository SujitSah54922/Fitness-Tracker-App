import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Workout } from '../models/workout.model';
import { WorkoutRequest } from '../models/workoutrequest.model';

@Injectable({
  providedIn: 'root'
})
export class WorkoutService {

  public apiUrl = "https://8080-dadeabbedbededefdfdaedcbdcbcedfafbbbceaed.premiumproject.examly.io"; //write apiUrl here

  constructor(private http: HttpClient) { }

  private getAuthHeaders(): HttpHeaders {
    const token = localStorage.getItem('jwtToken');
    return new HttpHeaders({
      'Authorization': `Bearer ${token}`
    });
  }

  getAllWorkouts(): Observable<Workout[]> {
    return this.http.get<Workout[]>(`${this.apiUrl}/api/workout`, { headers: this.getAuthHeaders() });
  }

  deleteWorkout(workoutId: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/api/workout/${workoutId}`, { headers: this.getAuthHeaders() });
  }

  getWorkoutById(id: number): Observable<Workout> {
    return this.http.get<Workout>(`${this.apiUrl}/api/workout/${id}`, { headers: this.getAuthHeaders() });
  }

  addWorkout(requestObject: Workout): Observable<Workout> {
    return this.http.post<Workout>(`${this.apiUrl}/api/workout`,requestObject, { headers: this.getAuthHeaders() });
  }

  updateWorkout(id: number, requestObject: Workout): Observable<Workout> {
    return this.http.put<Workout>(`${this.apiUrl}/api/workout?workoutId=${id}`, requestObject, { headers: this.getAuthHeaders() });
  }

  getAppliedWorkouts(userId: string): Observable<WorkoutRequest[]> {
    return this.http.get<WorkoutRequest[]>(`${this.apiUrl}/${userId}`, { headers: this.getAuthHeaders() });
  }

}
