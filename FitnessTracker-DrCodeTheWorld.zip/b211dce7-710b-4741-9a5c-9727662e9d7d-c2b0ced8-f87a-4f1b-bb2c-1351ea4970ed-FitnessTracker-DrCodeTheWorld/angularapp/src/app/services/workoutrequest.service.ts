import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { WorkoutRequest } from '../models/workoutrequest.model';

@Injectable({
  providedIn: 'root'
})
export class WorkoutrequestService {
  public apiUrl = "https://8080-dadeabbedbededefdfdaedcbdcbcedfafbbbceaed.premiumproject.examly.io";

  constructor(private http: HttpClient) {}

  private getHeaders(): HttpHeaders {
    const token = localStorage.getItem('authToken');
    return new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`
    });
  }

  addWorkoutRequest(data: WorkoutRequest): Observable<WorkoutRequest> {
    return this.http.post<WorkoutRequest>(`${this.apiUrl}/api/workoutrequests`, data, { headers: this.getHeaders() });
  }

  getAppliedWorkouts(userId: string): Observable<WorkoutRequest[]> {
    console.log('in get Applied workouts by id' + userId);
    const url = `${this.apiUrl}/api/workoutrequests/${userId}`;
    console.log(url);
    return this.http.get<WorkoutRequest[]>(url, { headers: this.getHeaders() });
  }

  deleteWorkoutApplication(requestedId: number): Observable<void> {
    const url = `${this.apiUrl}/api/workoutrequests/${requestedId}`;
    return this.http.delete<void>(url, { headers: this.getHeaders() });
  }

  getAllWorkoutRequests(): Observable<WorkoutRequest[]> {
    return this.http.get<WorkoutRequest[]>(`${this.apiUrl}/api/workoutrequests`, { headers: this.getHeaders() });
  }

  updateWorkoutStatus(id: number, workoutApplication: WorkoutRequest): Observable<WorkoutRequest> {
    //const url = `${this.apiUrl}/${id}`;
    return this.http.put<WorkoutRequest>(`${this.apiUrl}/api/workoutrequests/${id}`,workoutApplication, { headers: this.getHeaders() });
  }
}
