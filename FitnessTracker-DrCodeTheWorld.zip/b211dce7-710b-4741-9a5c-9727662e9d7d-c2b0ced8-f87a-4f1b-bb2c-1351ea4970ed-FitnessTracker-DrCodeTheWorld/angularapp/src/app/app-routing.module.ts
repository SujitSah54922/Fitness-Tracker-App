import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './components/login/login.component';
import { RegistrationComponent } from './components/registration/registration.component';
import { HomeComponent } from './components/home/home.component';
import { AuthGuard } from './authguard/auth.guard';
import { AdminnavComponent } from './components/adminnav/adminnav.component';
import { AdminaddworkoutComponent } from './components/adminaddworkout/adminaddworkout.component';
import { AdminviewworkoutComponent } from './components/adminviewworkout/adminviewworkout.component';
import { AdmineditworkoutComponent } from './components/admineditworkout/admineditworkout.component';
import { AdminviewfeedbackComponent } from './components/adminviewfeedback/adminviewfeedback.component';
import { UserviewworkoutComponent } from './components/userviewworkout/userviewworkout.component';
import { UserappliedworkoutComponent } from './components/userappliedworkout/userappliedworkout.component';
import { UserworkoutformComponent } from './components/userworkoutform/userworkoutform.component';
import { UserviewfeedbackComponent } from './components/userviewfeedback/userviewfeedback.component';
import { UseraddfeedbackComponent } from './components/useraddfeedback/useraddfeedback.component';
import { RequestedworkoutComponent } from './components/requestedworkout/requestedworkout.component';

const routes: Routes = [
  {path:'login', component: LoginComponent},
  {path:'register', component: RegistrationComponent},
  {path: 'admin',component: HomeComponent,canActivate: [AuthGuard]},
  {path:'admin/workout', component:AdminaddworkoutComponent,canActivate: [AuthGuard]},
  {path:'admin/addworkout', component:AdminaddworkoutComponent,canActivate: [AuthGuard]},
  {path:'adminViewWorkouts', component:AdminviewworkoutComponent,canActivate: [AuthGuard]},
  {path:'admin/viewworkout', component:AdminviewworkoutComponent,canActivate: [AuthGuard]},
  {path:'editAdminWorkout/:id', component:AdmineditworkoutComponent,canActivate: [AuthGuard]},
  {path:'feedbacks', component:AdminviewfeedbackComponent,canActivate: [AuthGuard]},
  {path:'workoutRequest', component:RequestedworkoutComponent,canActivate: [AuthGuard]},
  {path:'home', component:HomeComponent,canActivate: [AuthGuard]},
  {path: 'user',component: HomeComponent,canActivate: [AuthGuard]},
  {path:'user/workout', component:UserviewworkoutComponent,canActivate: [AuthGuard]},
  {path:'user/applyform/:workId', component:UserworkoutformComponent,canActivate: [AuthGuard]},
  {path:'userappliedworkout', component:UserappliedworkoutComponent,canActivate: [AuthGuard]},
  {path:'userviewFeedback', component:UserviewfeedbackComponent,canActivate: [AuthGuard]},
  {path:'add-feedback', component:UseraddfeedbackComponent,canActivate: [AuthGuard]},
  {path:'view-feedback', component:UserviewfeedbackComponent,canActivate: [AuthGuard]},
  {path:'appliedWorkoutRequest', component:UserappliedworkoutComponent,canActivate: [AuthGuard]},
  {path:'feedback', component:UseraddfeedbackComponent,canActivate: [AuthGuard]},
  {path:'',component:HomeComponent},
  {path:'',redirectTo:'/home',pathMatch:'full'}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
