using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using dotnetapp.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using Microsoft.Extensions.Configuration;
using System.Reflection.Emit;



namespace dotnetapp.Controllers
{
    [ApiController]
    [Route("api/")]
    public class UserController : ControllerBase
    {
        ApplicationDbContext _context;
        private readonly IConfiguration _configuration;
        public UserController(ApplicationDbContext context, IConfiguration configuration)
        {
            _context = context;
            _configuration= configuration;
        }

        [HttpPost("users/register")]
        public async Task<ActionResult<User>> Register(User user)
        {

            Console.WriteLine("/n/n/n/n In register/n/n/n/n");
            User _user = _context.Users.Where(x => x.Username == user.Username).FirstOrDefault();

            if (_user != null)
            {
                return Conflict();
            }

            bool flag = IsValidRole(user.Role);
            if (!flag)
            {
                return BadRequest();
            }

            _context.Users.Add(user);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(Register), user);
        }

        // [HttpPost("users/login")]
        // public async Task<ActionResult<object>> Login(LoginModel user)
        // {

        //     Console.WriteLine("/n/n/n/n/n/n In Login /n/n/n/n/n/n/n");

        //     User _user = _context.Users.Where(x => x.Username == user.Username).FirstOrDefault();

        //     if (_user == null)
        //     {
        //         return BadRequest("Login Failure");
        //     }

        //     return Ok(new { message = "Successful Login", user = _user });
        // }

        [HttpPost("users/login")]
        public IActionResult Login([FromBody] LoginModel model)
        {
            // Console.WriteLine("/n/n/n/n/n/n Entered Login /n/n/n/n/n/n/n");
            User _user = _context.Users.Where(x => x.Username == model.Username).FirstOrDefault();

            // Validate user credentials here (e.g., against a database)
            if (model.Username == _user.Username && model.Password == _user.Password)
            {
                var tokenHandler = new JwtSecurityTokenHandler();
                var key = Encoding.ASCII.GetBytes(_configuration["Jwt:Key"]);
                var tokenDescriptor = new SecurityTokenDescriptor
                {
                    Subject = new ClaimsIdentity(new Claim[]
                    {
                    new Claim(ClaimTypes.Name, model.Username),
                    new Claim( ClaimTypes.Role, _user.Role)
                    }),
                    Expires = DateTime.UtcNow.AddHours(1),
                    SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature),
                    Issuer = _configuration["Jwt:Issuer"]
            
                };
                var token = tokenHandler.CreateToken(tokenDescriptor);
                // Console.WriteLine("/n/n/n/n/n/n");
                // Console.WriteLine("Token Created");
                // Console.WriteLine(token);
                return Ok(new
                {
                    message = "Successful Login",
                    user = _user,
                    Token = tokenHandler.WriteToken(token)
                });
            }
            // Console.WriteLine("NotOk");
            return BadRequest("Login Failure");
        }

        [NonAction]
        public bool IsValidRole(string role)
        {
            List<string> validRoles = new List<string> { "Admin", "Organizer" };

            if (!validRoles.Contains(role, StringComparer.OrdinalIgnoreCase))
            {
                return false;
            }
            return true;
        }
    }
}