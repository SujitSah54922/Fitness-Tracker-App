using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Emit;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace dotnetapp.Models
{
    public class ApplicationDbContext:DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options):base(options){

        }

        public DbSet<Team> Teams{get; set;}
        public DbSet<Player> Players{get; set;}
        public DbSet<User> Users{get; set;}

        protected override void OnModelCreating(ModelBuilder builder){
            builder.Entity<Player>()
                .HasOne<Team>(p=>p.Team)
                .WithMany(t=>t.Players)
                .HasForeignKey(p=>p.TeamId)
                .OnDelete(DeleteBehavior.Cascade);
            
            base.OnModelCreating(builder);
        }
    }
}