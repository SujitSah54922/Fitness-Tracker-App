import { LoginModel } from './login-model.model';

describe('Login Models', () => {
  fit('Week6_Day3_should_create_Login_Model_instance', () => {
    const loginData: LoginModel = {
      Username: 'John',
      Password: "Test@123"
    };
    expect(loginData).toBeTruthy();
    expect(loginData.Username).toBe('John');
    expect(loginData.Password).toBe('Test@123');
  });
});
