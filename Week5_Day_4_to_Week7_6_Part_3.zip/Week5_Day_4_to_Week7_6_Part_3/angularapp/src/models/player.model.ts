import {Team} from './team.model';

export interface Player {
        Id?: any;
        Name?:string;
        Age?:number;
        Category?:string;
        BiddingPrice?:number;
        TeamId?:number;
        Team?:Team;

}

