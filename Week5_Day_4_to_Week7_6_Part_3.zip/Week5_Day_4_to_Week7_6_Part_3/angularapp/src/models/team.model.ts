import { Player } from "./player.model";

export interface Team{
    Id?:number;
    Name:string; 
    MaximumBudget:number;
    Players?:Player[];
}
