export interface User{
    Id?:number;
    Username:string;
    Password:string;
    Role:('Admin' | 'Organizer');
    // Role:string;
}