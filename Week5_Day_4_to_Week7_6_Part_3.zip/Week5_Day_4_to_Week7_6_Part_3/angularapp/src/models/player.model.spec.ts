import { Player } from './player.model';

describe('Player Models', () => {
  fit('Week6_Day3_should_create_Player_instance', () => {
    const player: Player = {
      Name: 'John',
      Age: 25,
      Category: 'A',
      BiddingPrice: 100,
    };
    expect(player).toBeTruthy();
    expect(player.Name).toBe('John');
    expect(player.Age).toBe(25);
    expect(player.Category).toBe('A');
    expect(player.BiddingPrice).toBe(100);
  });

  // it('Week4_Day3_should_create_Player_instance_with_default_values', () => {
  //   const player: Player = {
  //     name: 'Jane',
  //     age: 30
  //   };
  //   expect(player).toBeTruthy();
  //   expect(player.name).toBe('Jane');
  //   expect(player.age).toBe(30);
  //   expect(player.category).toBeUndefined();
  //   expect(player.biddingPrice).toBeUndefined();
  //   expect(player.selectedTeamId).toBeUndefined();
  // });
});
