import { Component, OnInit } from '@angular/core';
import { TeamService } from '../services/team.service';
import { Team } from 'src/models/team.model';
import { Player } from 'src/models/player.model';
import { PlayerService } from '../services/player.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {

  teams: Team[];
  editedTeam: Team = {
    Name: '',
    MaximumBudget: 0
  };

  players: Player[];
  editedPlayer: Player = {}

  constructor(private teamService: TeamService, private playerService: PlayerService) { }

  ngOnInit(): void {
    this.getTeams();
    this.getPlayers();
  }

  getTeams() {
    this.teamService.getTeams().subscribe(
      data => {
        this.teams = data;
        console.log(this.teams);
      }
    );
  }

  editTeam(team: Team) {
    this.editedTeam = team;
  }

  saveEditedTeam() {
    this.teamService.updateTeam(this.editedTeam.Id, this.editedTeam).subscribe(
      response =>{
        if(response) this.getTeams();
      }
    );
  }

  cancelEditTeam() {
    this.editedTeam = {
      Name: '',
      MaximumBudget: 0
    }
  }

  deleteTeam(teamId: number){
    this.teamService.deleteTeam(teamId).subscribe(
      () =>{
        this.getTeams();
      }
    );
  }

  getPlayers(){
    return this.playerService.getPlayers().subscribe(
      data=>{
        this.players = data;
        console.log(this.players);
      }
    )
  }

  editPlayer(player: Player){
    this.editedPlayer = player;
  }

  saveEditedPlayer(){
    this.playerService.updatePlayer(this.editedPlayer.Id, this.editedPlayer).subscribe();
    this.getPlayers();
  }

  cancelEditPlayer(){
    this.editedPlayer = {};
  }

  deletePlayer(playerId: number){
    this.playerService.deletePlayer(playerId).subscribe();
    this.getPlayers();
  }
}
