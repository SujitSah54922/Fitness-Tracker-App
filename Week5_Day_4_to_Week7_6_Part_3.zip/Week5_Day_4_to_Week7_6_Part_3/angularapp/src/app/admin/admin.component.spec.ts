import { ComponentFixture, TestBed, fakeAsync, tick } from '@angular/core/testing';
import { AdminComponent } from './admin.component';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';

describe('AdminComponent', () => {
  let component: AdminComponent;
  let fixture: ComponentFixture<AdminComponent>;


  beforeEach(() => {

    TestBed.configureTestingModule({
      imports: [FormsModule, HttpClientModule]
    });

    fixture = TestBed.createComponent(AdminComponent);
    component = fixture.componentInstance;
  });

  fit('Week6_Day3_should_create_Admin_Component', () => {
    expect(component).toBeTruthy();
  });

  fit('Week7_Day2_should define getTeams_createTeam_deleteTeam_editTeam functions in Admin Component', () => {
    // expect(component['createTeam']).toBeTruthy();
    expect(component['editTeam']).toBeTruthy();
    expect(component['deleteTeam']).toBeTruthy();
    expect(component['getTeams']).toBeTruthy();
  });

  fit('Week7_Day2_should define getPlayers_createPlayer_editPlayer_deletePlayer function in Admin Component', () => {
    expect(component['getPlayers']).toBeTruthy();
    // expect(component['createPlayer']).toBeTruthy();
    expect(component['editPlayer']).toBeTruthy();
    expect(component['deletePlayer']).toBeTruthy();
  });

});
