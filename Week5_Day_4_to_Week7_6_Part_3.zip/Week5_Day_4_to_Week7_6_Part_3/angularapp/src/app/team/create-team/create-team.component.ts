import { Component, OnInit } from '@angular/core';
import { TeamService } from 'src/app/services/team.service';
import { Team } from 'src/models/team.model';

@Component({
  selector: 'app-create-team',
  templateUrl: './create-team.component.html',
  styleUrls: ['./create-team.component.css']
})
export class CreateTeamComponent implements OnInit {

  team: Team = {
    Name: '',
    MaximumBudget: 0,
    Players: new Array()
  }


  maxBiddingStatus(): string {
    if (this.team.MaximumBudget > 5000) {
      return 'Good Bidding';
    }
    else if (this.team.MaximumBudget > 1000 && this.team.MaximumBudget < 5000) {
      return 'Low';
    }
    else {
      return 'Too Low';
    }
  }
  constructor(private service: TeamService) { }

  ngOnInit(): void {
  }

  createTeam() {
    console.log(this.team);
    this.service.createTeam(this.team).subscribe();
  }
}
