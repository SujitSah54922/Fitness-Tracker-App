import { Component, Input, OnInit, Output, EventEmitter } from '@angular/core';
import { TeamService } from '../services/team.service';
import { Team } from 'src/models/team.model';

@Component({
  selector: 'app-team',
  templateUrl: './team.component.html',
  styleUrls: ['./team.component.css']
})
export class TeamComponent implements OnInit {

  constructor(private teamService : TeamService) { }
  
  ngOnInit(): void {
  }

  @Input() teams : Team[];
  @Input() editedTeam : Team ={
    Name: '',
    MaximumBudget: 0
  };


  @Output() editTeamEvent = new EventEmitter();
  @Output() saveEditedTeamEvent = new EventEmitter();
  @Output() cancelEditTeamEvent = new EventEmitter();
  @Output() deleteTeamEvent = new EventEmitter();


  onEditTeam(team: Team){
    console.log("inside edit");
    console.log(team);
    this.editTeamEvent.emit(team);
  }

  onSaveEditedTeam(){
    this.saveEditedTeamEvent.emit();
  }

  onCancelEditTeam(){
    this.cancelEditTeamEvent.emit();
  }

  onDeleteTeam(teamId: number){
    this.deleteTeamEvent.emit(teamId);
  }

}
