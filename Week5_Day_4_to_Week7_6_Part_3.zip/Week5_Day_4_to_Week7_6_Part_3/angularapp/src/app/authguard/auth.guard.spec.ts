import { TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { Router } from '@angular/router';
import { AuthGuard } from './auth.guard';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { FormsModule } from '@angular/forms';

describe('AuthGuard', () => {
  // let authServiceSpy: jasmine.SpyObj<AuthService>;
  let router: Router;

  beforeEach(() => {
    // authServiceSpy = jasmine.createSpyObj('AuthService', ['isLoggedIn']);

    TestBed.configureTestingModule({
      imports: [RouterTestingModule, HttpClientTestingModule, FormsModule],
      providers: [
        AuthGuard,
        // { provide: AuthService, useValue: authServiceSpy },
      ],
    });

    router = TestBed.inject(Router);
  });

  fit('Week7_Day2_AuthGuard_should_be_created', () => {
    const guard = TestBed.inject(AuthGuard);
    expect(guard).toBeTruthy();
  });

  // it('should allow access when the user is logged in', () => {
  //   authServiceSpy['isLoggedIn'].and.returnValue(true);

  //   const guard = TestBed.inject(AuthGuard);
  //   const canActivate = guard['canActivate'](null, null);

  //   expect(canActivate).toBeTrue();
  // });

  // fit('frontend_AuthGuard_should redirect to login page when the user is not logged in', () => {
  //   authServiceSpy['isLoggedIn'].and.returnValue(false);
  //   const navigateSpy = spyOn(router, 'navigate');

  //   const guard = TestBed.inject(AuthGuard);
  //   const canActivate = guard['canActivate'](null, null);

  //   expect(canActivate).toBeFalse();
  //   expect(navigateSpy).toHaveBeenCalledWith(['/login']);
  // });

  // fit('frontend_AuthGuard_should redirect to forbidden page when user does not have appropriate role', () => {
  //   authServiceSpy['isLoggedIn'].and.returnValue(true);
  //   authServiceSpy['isAdmin'].and.returnValue(false);
  //   authServiceSpy['isCustomer'].and.returnValue(false);

  //   const navigateSpy = spyOn(router, 'navigate');

  //   const guard = TestBed.inject(AuthGuard);
  //   const canActivate = guard['canActivate']({ url: [{ path: 'admin' }] } as any, null);

  //   expect(canActivate).toBeFalse();
  //   expect(navigateSpy).toHaveBeenCalledWith(['/forbidden']);
  // });

});
