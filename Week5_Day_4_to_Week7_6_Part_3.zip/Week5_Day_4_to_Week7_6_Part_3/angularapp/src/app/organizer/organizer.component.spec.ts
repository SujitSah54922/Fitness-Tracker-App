import { ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms'; // Import FormsModule
import { RouterTestingModule } from '@angular/router/testing';
import { OrganizerComponent } from './organizer.component';
import { Player } from 'src/models/player.model';
import { By } from '@angular/platform-browser';

describe('OrganizerComponent', () => {
  let component: OrganizerComponent;
  let fixture: ComponentFixture<OrganizerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ OrganizerComponent ],
      imports: [ FormsModule, HttpClientModule, RouterTestingModule ] // Add FormsModule here
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(OrganizerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  fit('Week6_Day3_should_create_Organizer_Component', () => {
    expect(component).toBeTruthy();
  });

  fit('Week7_Day3_OrganizerComponent_should display No_Unsold_Players with id no_unsold', () => {
    // component.unsoldPlayers = [];
    // fixture.detectChanges();
    const noUnsoldPlayersElement = fixture.debugElement.query(By.css('#no_unsold'));
    expect(noUnsoldPlayersElement).toBeTruthy();
    expect(noUnsoldPlayersElement.nativeElement.textContent).toContain('No Unsold Players');
  });

  fit('Week7_Day3_OrganizerComponent_should display unsold players when unsoldPlayers is not empty in Table', () => {
    const mockPlayers: Player[] = [
      { Name: 'Player 1', Age: 25, Category: 'Category 1', BiddingPrice: 100, TeamId:  null},
      { Name: 'Player 2', Age: 28, Category: 'Category 2', BiddingPrice: 150, TeamId: null }
    ];
    component['unsoldPlayers'] = mockPlayers;
    fixture.detectChanges();
    const playerRows = fixture.debugElement.queryAll(By.css('tbody tr'));

    expect(playerRows.length).toEqual(mockPlayers.length);
  });

  fit('Week7_Day3_OrganizerComponent_should display No_Teams_Available with id no_team', () => {
    // component.teams = [];
    // fixture.detectChanges();
    const noTeamsElement = fixture.debugElement.query(By.css('#no_teams'));
    expect(noTeamsElement).toBeTruthy();
    expect(noTeamsElement.nativeElement.textContent).toContain('No Teams Available');
  });

  fit('Week7_Day3_OrganizerComponent_should define assignPlayerToTeam_releasePlayerFromTeam function', () => {
    expect(component['assignPlayerToTeam']).toBeTruthy();
    expect(component['releasePlayerFromTeam']).toBeTruthy();
  });

});
