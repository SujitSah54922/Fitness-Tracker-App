import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import {tap} from 'rxjs/operators'
import { HttpClient } from '@angular/common/http';
import { User } from 'src/models/user.model';
import { LoginModel } from 'src/models/login-model.model';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  baseUrl='https://8080-bcedecccfcfcbe314885997fbcbabfbfeone.premiumproject.examly.io/api/users';
  constructor(private http:HttpClient) { }

  register(newUser:User):Observable<User>
  {
    return this.http.post<User>(`${this.baseUrl}/register`,newUser);
  }

  login(loginUser:LoginModel):Observable<any>
  {
    return this.http.post<any>(`${this.baseUrl}/login`,loginUser).pipe(
      tap((response)=>{
        if(response && response.Token)
        {
          console.log(response.Token);
          const tokenPart=response.Token.split('.'); 
          let payload=JSON.parse(atob(tokenPart[1]));

          localStorage.setItem('userRole',payload.role);
        }
      }
      )
    )
  }

  isLoggedIn()
  {
    if(localStorage.getItem('userRole')==='Admin' || localStorage.getItem('userRole')==='Organizer')
    {
      return true;
    } 
    return false;
  }

  isAdmin()
  {
    return localStorage.getItem('userRole')==='Admin';
  }
  
  isOrganizer()
  {
    return localStorage.getItem('userRole')==='Organizer';

  }

  logout()
  {
    localStorage.clear(); 
  }

}
