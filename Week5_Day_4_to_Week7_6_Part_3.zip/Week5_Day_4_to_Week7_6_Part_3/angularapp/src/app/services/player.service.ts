import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { Player } from 'src/models/player.model';

@Injectable({
  providedIn: 'root'
})
export class PlayerService {

  baseUrl='https://8080-bcedecccfcfcbe314885997fbcbabfbfeone.premiumproject.examly.io/api/Player';
  constructor(private http:HttpClient) { }

  getPlayers():Observable<Player[]>
  {
    return this.http.get<Player[]>(`${this.baseUrl}/GetPlayers`);
  }

  createPlayer(player:Player):Observable<Player>
  {
    return this.http.post<Player>(`${this.baseUrl}/PostPlayer`,player);
  }

  updatePlayer(playerId:number,player:Player):Observable<Player>
  {
    return this.http.put<Player>(`${this.baseUrl}/PutPlayer/${playerId}`,player);
  }

  deletePlayer(playerId:number):Observable<void>
  {
    return this.http.delete<void>(`${this.baseUrl}/DeletePlayer/${playerId}`);
  }

}
