import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Team } from 'src/models/team.model';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class TeamService {

  baseUrl='https://8080-bcedecccfcfcbe314885997fbcbabfbfeone.premiumproject.examly.io/api/Team';

  constructor(private http:HttpClient) { }

  getTeams():Observable<Team[]>
  {
    return this.http.get<Team[]>(`${this.baseUrl}/GetTeams`);
  }

  createTeam(team:Team):Observable<Team>
  {
    return this.http.post<Team>(`${this.baseUrl}/PostTeam`,team);
  }

  updateTeam(teamId:number,team:Team):Observable<Team>
  {
    return this.http.put<Team>(`${this.baseUrl}/PutTeam/${teamId}`,team);
  }

  deleteTeam(teamId:number):Observable<void>
  {
    return this.http.delete<void>(`${this.baseUrl}/DeleteTeam/${teamId}`);
  }

}
