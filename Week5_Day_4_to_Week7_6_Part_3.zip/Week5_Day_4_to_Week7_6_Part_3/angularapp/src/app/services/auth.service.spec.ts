import { TestBed } from '@angular/core/testing';
import { AuthService } from './auth.service';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { User } from 'src/models/user.model';
import { LoginModel } from 'src/models/login-model.model';

describe('AuthService', () => {
  let service: AuthService;
  let httpMock: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule]
    });
    service = TestBed.inject(AuthService);
    httpMock = TestBed.inject(HttpTestingController);

  });

  afterEach(() => {
    httpMock.verify();
  });

  fit('Week7_Day1_should_create_authServices', () => {
    expect(service).toBeTruthy();
  });

  fit('Week7_Day1_AuthService_should register a new User', () => {
    const mockuser: User = {
      Id: 1,
      Username: 'Test Player',
      Password: "Test@123",
      Role: 'Admin'
    };

    service['register'](mockuser).subscribe((createduser: User) => {
      expect(createduser).toEqual(mockuser);
    });

    const req = httpMock.expectOne(`${service['baseUrl']}/register`);
    expect(req.request.method).toBe('POST');
    req.flush(mockuser);
  });

  fit('Week7_Day1_AuthService_should Login', () => {
    const mockuser: LoginModel = {
      Username: 'Test Player',
      Password: "Test@123"
    };

    service['login'](mockuser).subscribe((createduser: LoginModel) => {
      expect(createduser).toEqual(mockuser);
    });

    const req = httpMock.expectOne(`${service['baseUrl']}/login`);
    expect(req.request.method).toBe('POST');
    req.flush(mockuser);
  });

});
