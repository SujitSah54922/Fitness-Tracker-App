import { TestBed } from '@angular/core/testing';
import { TeamService } from './team.service';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { Team } from 'src/models/team.model';

describe('TeamService Integration Tests', () => {
  let service: TeamService;
  let httpMock: HttpTestingController;


  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [TeamService]
    });
    service = TestBed.inject(TeamService);
    httpMock = TestBed.inject(HttpTestingController);

    jasmine.DEFAULT_TIMEOUT_INTERVAL = 3000;

  });

  afterEach(() => {
    httpMock.verify();
  });

  fit('Week7_Day1_TeamService_should_be_created', () => {
    expect(service).toBeTruthy();
  });

  fit('Week7_Day1_TeamService_should_get_all_Teams', () => {
    const mockteams: Team[] = [
      { Id: 1, Name: 'Team 1', MaximumBudget: 1200000 },
      { Id: 2, Name: 'Team 2', MaximumBudget: 1500000 }
    ];

    service['getTeams']().subscribe((players: Team[]) => {
      expect(players[0].MaximumBudget).toEqual(mockteams[0].MaximumBudget);
      expect(players.length).toBeGreaterThan(0); // Check if any teams are retrieved
    });

    const req = httpMock.expectOne(`${service['baseUrl']}/GetTeams`);
    expect(req.request.method).toBe('GET');
    req.flush(mockteams);
  });

  fit('Week7_Day1_TeamService_should create a team', () => {
    const mockteam: Team = {
      Id: 1,
      Name: 'Test Team',
      MaximumBudget: 1200000
    };

    service['createTeam'](mockteam).subscribe((createdPlayer: Team) => {
      expect(createdPlayer.Name).toEqual(mockteam.Name);
    });

    const req = httpMock.expectOne(`${service['baseUrl']}/PostTeam`);
    expect(req.request.method).toBe('POST');
    req.flush(mockteam);
  });

  fit('Week7_Day1_TeamService_should update a team', () => {
    const teamId = 1;
    const updatedTeam: Team = {
      Id: teamId,
      Name: 'Updated Team',
      MaximumBudget: 4500000
    };

    service['updateTeam'](teamId, updatedTeam).subscribe((result: Team) => {
      expect(result).toEqual(updatedTeam);
    });

    const req = httpMock.expectOne(`${service['baseUrl']}/PutTeam/${teamId}`);
    expect(req.request.method).toBe('PUT');
    req.flush(updatedTeam);
  });

  fit('Week7_Day1_TeamService_should delete a team', () => {
    const teamId = 1;

    service['deleteTeam'](teamId).subscribe(() => {
    });

    const req = httpMock.expectOne(`${service['baseUrl']}/DeleteTeam/${teamId}`);
    expect(req.request.method).toBe('DELETE');
    req.flush(null);
  });
});

  // fit('Frontend_AdminService_should_create_a_new_team_via_the_backend', (done: DoneFn) => {
  //   const newTeam: any = { Name: 'New Team', Age: 25, Category: "Batting", BiddingPrice: 120000 };

  //   service['createPlayer'](newTeam).subscribe(
  //     (createdTeam: any) => {
  //       console.log("funny"+createdTeam);

  //       expect(createdTeam).toEqual(newTeam);
  //       done();
  //     },
  //     (error: any) => {
  //       fail('Failed to create team: ' + JSON.stringify(error));
  //     }
  //   );
  // });

  // fit('Frontend_AdminService_should_retrieve_players_from_the_backend', (done: DoneFn) => {
  //   service['getPlayers']().subscribe(
  //     (players: any[]) => {
  //       console.log(players)
  //       expect(players.length).toBeGreaterThan(0); // Check if any teams are retrieved
  //       done();
  //     },
  //     (error: any) => {
  //       fail('Failed to retrieve teams: ' + JSON.stringify(error));
  //     }
  //   );
  // });



  // Write similar test cases for other methods (updateTeam, deleteTeam, getPlayers, createPlayer, updatePlayer, deletePlayer)


