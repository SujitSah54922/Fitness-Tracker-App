import { ComponentFixture, TestBed, tick, fakeAsync } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import { CreatePlayerComponent } from './create-player.component';
import { HttpClientModule } from '@angular/common/http';
import { RouterTestingModule } from '@angular/router/testing';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';

describe('CreatePlayerComponent', () => {
  let component: CreatePlayerComponent;
  let fixture: ComponentFixture<CreatePlayerComponent>;
  let debugElement: DebugElement;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CreatePlayerComponent ],
      imports: [ FormsModule, HttpClientModule, RouterTestingModule ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CreatePlayerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    debugElement = fixture.debugElement;
  });

  fit('Week6_Day6_should_create_CreatePlayerComponent', () => {
    expect(component).toBeTruthy();
  });

  fit('Week6_Day6_should show playerName required error message on CreatePlayer page', fakeAsync(() => {
    // Query the input element
    const playerNameInput = debugElement.query(By.css('#playerName'));
    expect(playerNameInput).toBeTruthy();
    playerNameInput.nativeElement.value = '';

    playerNameInput.nativeElement.dispatchEvent(new Event('input'));
    fixture.detectChanges();
    tick();

    // Query the error message element
    const errorMessage = debugElement.query(By.css('.error-message'));
    expect(errorMessage.nativeElement.textContent).toContain('Player Name is required');
 }));

 fit('Week6_Day6_should show playerAge required error message on CreatePlayer page', fakeAsync(() => {
  // Query the input element
  const playerAgeInput = debugElement.query(By.css('#playerAge'));
  expect(playerAgeInput).toBeTruthy();
  playerAgeInput.nativeElement.value = '';

  playerAgeInput.nativeElement.dispatchEvent(new Event('input'));
  fixture.detectChanges();
  tick();

  // Query the error message element
  const errorMessage = debugElement.query(By.css('.error-message'));
  expect(errorMessage.nativeElement.textContent).toContain('Player Age is required');
}));


  // fit('Week6_Day6_should submit Create Player form when all fields are valid', fakeAsync(() => {
  //   spyOn(component as any, 'createPlayer');

  //   const compiled = fixture.nativeElement;
  //   const playerNameInput = compiled.querySelector('#playerName');
  //   const playerAgeInput = compiled.querySelector('#playerAge');
  //   const playerCategoryInput = compiled.querySelector('#playerCategory');
  //   const playerBiddingPriceInput = compiled.querySelector('#playerBiddingPrice');
  //   const submitButton = compiled.querySelector('#submit');

  //   // Fill form fields with valid values
  //   playerNameInput.value = 'John Doe';
  //   playerAgeInput.value = '20';
  //   playerCategoryInput.value = 'Forward';
  //   playerBiddingPriceInput.value = '100000';

  //   // Trigger input events to update ngModel values
  //   playerNameInput.dispatchEvent(new Event('input'));
  //   playerAgeInput.dispatchEvent(new Event('input'));
  //   playerCategoryInput.dispatchEvent(new Event('input'));
  //   playerBiddingPriceInput.dispatchEvent(new Event('input'));
  //   submitButton.click();
  //   tick();
  //   fixture.detectChanges();
  //   expect(component['createPlayer']).toHaveBeenCalled();
  // }));
});
