import { Component, Input, OnInit, Output, EventEmitter } from '@angular/core';
import { Player } from 'src/models/player.model';

@Component({
  selector: 'app-player',
  templateUrl: './player.component.html',
  styleUrls: ['./player.component.css']
})
export class PlayerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  @Input() players : Player[];
  @Input() editedPlayer : Player ={
    Id : null,
    Name : '',
    Age : null,
    Category : '',
    BiddingPrice : null,
    TeamId : null
  };

  @Output() editPlayerEvent = new EventEmitter();
  @Output() saveEditedPlayerEvent = new EventEmitter();
  @Output() cancelEditPlayerEvent = new EventEmitter();
  @Output() deletePlayerEvent = new EventEmitter();


  onEditPlayer(player: Player){
    this.editPlayerEvent.emit(player);
  }

  onSaveEditedPlayer(){
    this.saveEditedPlayerEvent.emit();
  }

  onCancelEditPlayer(){
    this.cancelEditPlayerEvent.emit();
  }

  onDeletePlayer(playerId: number){
    this.deletePlayerEvent.emit(playerId);
  }
}
