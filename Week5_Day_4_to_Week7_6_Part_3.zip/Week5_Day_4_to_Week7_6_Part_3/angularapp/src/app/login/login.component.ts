import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NgForm } from '@angular/forms';
import { AuthService } from '../services/auth.service';
import { LoginModel } from 'src/models/login-model.model';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  userLogin:LoginModel={
    Username: '',
    Password: ''
  }

  role:string='';
  
  constructor(private authService:AuthService,private router:Router) { }
  
  ngOnInit(): void {
  }
  
  login()
  {
    this.authService.login(this.userLogin).subscribe(()=>{
      console.log("Log in Succesfully");
      this.role=localStorage.getItem('userRole').toLowerCase();
      console.log(this.role);
      this.router.navigate([`/${this.role}`]);
    });
  }

}
