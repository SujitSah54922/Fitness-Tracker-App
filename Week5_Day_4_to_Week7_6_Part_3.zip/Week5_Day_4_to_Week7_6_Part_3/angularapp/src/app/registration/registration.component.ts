import { Component, OnInit } from '@angular/core';
export { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { User } from 'src/models/user.model';
import { AuthService } from '../services/auth.service';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {

  user:User={
    Username: '',
    Password: '',
    Role: 'Admin'
  }

  constructor(private authService:AuthService,private router:Router) { }

  ngOnInit(): void {
  }

  register()
  {
    // console.log(this.user.Username);
    // console.log(this.user.Password);
    // console.log(this.user.Role);
    this.authService.register(this.user).subscribe(()=>{
      this.router.navigate(['/login']);
    })
  }

}
